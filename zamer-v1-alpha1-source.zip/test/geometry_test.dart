import 'package:flutter_test/flutter_test.dart';
import 'package:zamer_app/models/project.dart';
import 'package:zamer_app/services/geometry.dart';

void main() {
  test('opposite parallel wall prefers full 4800 wall over 1970 fragment', () {
    final candidate = WallSegment(id: 'new', a: const PlanPoint(0, 3000), b: const PlanPoint(4700, 3000));
    final full = WallSegment(id: 'full', a: const PlanPoint(0, 0), b: const PlanPoint(4800, 0));
    final fragment = WallSegment(id: 'fragment', a: const PlanPoint(500, 1500), b: const PlanPoint(2470, 1500), isPartition: true);
    final result = GeometryService.findOppositeParallelWall(candidate, [fragment, full]);
    expect(result, isNotNull);
    expect(result!.wall.id, 'full');
    expect(result.wall.length.round(), 4800);
  });

  test('floor clone duplicates geometry independently', () {
    final p = ZamerProject.demo();
    p.addFloorByCopy();
    expect(p.floors.length, 2);
    expect(p.floors[1].walls.length, p.floors[0].walls.length);
    p.floors[1].walls.first.a = const PlanPoint(500, 500);
    expect(p.floors[0].walls.first.a.x, 0);
  });

  test('opening offset follows projected point', () {
    final wall = WallSegment(id: 'w', a: const PlanPoint(0, 0), b: const PlanPoint(4000, 0));
    expect(GeometryService.openingOffsetForPoint(wall, const PlanPoint(2000, 300)), closeTo(.5, .001));
  });
}

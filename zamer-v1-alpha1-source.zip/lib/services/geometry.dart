import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/project.dart';

class ParallelWallSuggestion {
  const ParallelWallSuggestion(this.wall, this.distance, this.score);
  final WallSegment wall;
  final double distance;
  final double score;
}

class GeometryService {
  static const double _angleTolerance = 3 * math.pi / 180;

  static double normalizeAngle(double a) {
    while (a > math.pi) a -= 2 * math.pi;
    while (a < -math.pi) a += 2 * math.pi;
    return a;
  }

  static double angleDistance(double a, double b) {
    final d = normalizeAngle(a - b).abs();
    return math.min(d, (math.pi - d).abs());
  }

  static Offset projectOnSegment(Offset p, Offset a, Offset b) {
    final ab = b - a;
    final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
    if (len2 == 0) return a;
    var t = ((p.dx - a.dx) * ab.dx + (p.dy - a.dy) * ab.dy) / len2;
    t = t.clamp(0.0, 1.0).toDouble();
    return Offset(a.dx + ab.dx * t, a.dy + ab.dy * t);
  }

  static double pointSegmentDistance(Offset p, Offset a, Offset b) =>
      (p - projectOnSegment(p, a, b)).distance;

  static double overlapOnAxis(WallSegment a, WallSegment b) {
    final ux = math.cos(a.angle);
    final uy = math.sin(a.angle);
    double proj(PlanPoint p) => p.x * ux + p.y * uy;
    final a1 = math.min(proj(a.a), proj(a.b));
    final a2 = math.max(proj(a.a), proj(a.b));
    final b1 = math.min(proj(b.a), proj(b.b));
    final b2 = math.max(proj(b.a), proj(b.b));
    return math.max(0.0, math.min(a2, b2) - math.max(a1, b1)).toDouble();
  }

  /// Finds a wall that is actually opposite the candidate wall, not merely
  /// the nearest random parallel fragment. It requires a useful projected
  /// overlap and ranks long overlapping walls above tiny partitions.
  static ParallelWallSuggestion? findOppositeParallelWall(
    WallSegment candidate,
    Iterable<WallSegment> walls, {
    double maxDistance = 12000,
  }) {
    ParallelWallSuggestion? best;
    for (final wall in walls) {
      if (wall.id == candidate.id) continue;
      if (angleDistance(candidate.angle, wall.angle) > _angleTolerance) continue;

      final overlap = overlapOnAxis(candidate, wall);
      final minRequired = math.min(candidate.length, wall.length).toDouble() * .35;
      if (overlap < math.max(250.0, minRequired).toDouble()) continue;

      final cMid = Offset((candidate.a.x + candidate.b.x) / 2, (candidate.a.y + candidate.b.y) / 2);
      final wA = wall.a.offset;
      final wB = wall.b.offset;
      final distance = pointSegmentDistance(cMid, wA, wB);
      if (distance > maxDistance) continue;

      // Reward overlap and similar/longer wall length, penalize distance.
      final lengthFit = math.min(candidate.length, wall.length).toDouble() / math.max(candidate.length, wall.length).toDouble();
      final score = (overlap * 2.0 + wall.length * .65 + lengthFit * 2000 - distance * .12).toDouble();
      if (best == null || score > best.score) {
        best = ParallelWallSuggestion(wall, distance, score);
      }
    }
    return best;
  }

  static PlanPoint snapPoint(PlanPoint p, {double grid = 50}) => PlanPoint(
        (p.x / grid).round() * grid,
        (p.y / grid).round() * grid,
      );

  static double openingOffsetForPoint(WallSegment wall, PlanPoint point) {
    final a = wall.a.offset;
    final b = wall.b.offset;
    final ab = b - a;
    final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
    if (len2 == 0) return .5;
    final t = ((point.x - a.dx) * ab.dx + (point.y - a.dy) * ab.dy) / len2;
    return t.clamp(0.02, 0.98).toDouble();
  }
}

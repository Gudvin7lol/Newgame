import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/project.dart';
import '../services/geometry.dart';

class PlanCanvas extends StatefulWidget {
  const PlanCanvas({super.key, required this.project, this.onMessage});
  final ZamerProject project;
  final ValueChanged<String>? onMessage;

  @override
  State<PlanCanvas> createState() => _PlanCanvasState();
}

class _PlanCanvasState extends State<PlanCanvas> {
  PlanPoint? draftStart;
  String? draggingWallId;
  bool dragWallStart = true;
  String? draggingOpeningId;

  ZamerProject get p => widget.project;

  Rect _bounds() {
    final pts = p.floor.walls.expand((w) => [w.a, w.b]).toList();
    final minX = pts.map((e) => e.x).reduce(math.min);
    final minY = pts.map((e) => e.y).reduce(math.min);
    final maxX = pts.map((e) => e.x).reduce(math.max);
    final maxY = pts.map((e) => e.y).reduce(math.max);
    return Rect.fromLTRB(minX - 700, minY - 700, maxX + 700, maxY + 700);
  }

  _Transform _transform(Size size) => _Transform.fit(_bounds(), size);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final size = Size(c.maxWidth, c.maxHeight);
      final tr = _transform(size);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) => _tap(tr.toWorld(d.localPosition)),
        onPanStart: (d) => _panStart(tr.toWorld(d.localPosition)),
        onPanUpdate: (d) => _panUpdate(tr.toWorld(d.localPosition)),
        onPanEnd: (_) => _panEnd(),
        child: CustomPaint(
          painter: _PlanPainter(project: p, tr: tr, draftStart: draftStart),
          child: const SizedBox.expand(),
        ),
      );
    });
  }

  WallSegment? _nearestWall(PlanPoint point, {double max = 260}) {
    WallSegment? best;
    var bd = max;
    for (final w in p.floor.walls) {
      final d = GeometryService.pointSegmentDistance(point.offset, w.a.offset, w.b.offset);
      if (d < bd) { bd = d; best = w; }
    }
    return best;
  }

  Opening? _nearestOpening(PlanPoint point, {double max = 300}) {
    Opening? best;
    var bd = max;
    for (final o in p.floor.openings) {
      final w = p.floor.walls.firstWhere((e) => e.id == o.wallId);
      final pos = Offset(
        w.a.x + (w.b.x - w.a.x) * o.offset,
        w.a.y + (w.b.y - w.a.y) * o.offset,
      );
      final d = (point.offset - pos).distance;
      if (d < bd) { bd = d; best = o; }
    }
    return best;
  }

  void _tap(PlanPoint world) async {
    final snapped = GeometryService.snapPoint(world);
    if (p.tool == ToolMode.wall || p.tool == ToolMode.partition) {
      if (draftStart == null) {
        setState(() => draftStart = snapped);
        widget.onMessage?.call('Укажи конец стены');
        return;
      }
      final draft = WallSegment(
        id: 'w_${DateTime.now().microsecondsSinceEpoch}',
        a: draftStart!,
        b: snapped,
        thickness: p.tool == ToolMode.partition ? 100 : 180,
        phase: ProjectPhase.newPlan,
        isPartition: p.tool == ToolMode.partition,
      );
      if (draft.length < 150) { setState(() => draftStart = null); return; }
      final suggestion = GeometryService.findOppositeParallelWall(draft, p.floor.walls);
      var wall = draft;
      if (suggestion != null && mounted) {
        final proposed = suggestion.wall.length.round();
        final use = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
          title: const Text('Параллельная стена'),
          content: Text('Напротив найдена цельная стена ${proposed} мм. Использовать её длину?'),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Оставить')), FilledButton(onPressed: () => Navigator.pop(context, true), child: Text('$proposed мм'))],
        ));
        if (use == true) {
          final dx = draft.b.x - draft.a.x;
          final dy = draft.b.y - draft.a.y;
          final l = draft.length;
          wall.b = PlanPoint(draft.a.x + dx / l * suggestion.wall.length, draft.a.y + dy / l * suggestion.wall.length);
        }
      }
      p.floor.walls.add(wall);
      p.updateWall(wall);
      setState(() => draftStart = null);
      return;
    }

    if (p.tool == ToolMode.door || p.tool == ToolMode.window) {
      final wall = _nearestWall(world);
      if (wall == null) return;
      final opening = Opening(
        id: 'o_${DateTime.now().microsecondsSinceEpoch}',
        wallId: wall.id,
        type: p.tool == ToolMode.door ? OpeningType.door : OpeningType.window,
        offset: GeometryService.openingOffsetForPoint(wall, world),
        width: p.tool == ToolMode.door ? 900 : 1400,
        height: p.tool == ToolMode.door ? 2100 : 1400,
        sillHeight: p.tool == ToolMode.window ? 850 : 0,
      );
      p.floor.openings.add(opening);
      p.selectOpening(opening.id);
      return;
    }

    final opening = _nearestOpening(world);
    if (opening != null) { p.selectOpening(opening.id); return; }
    final wall = _nearestWall(world);
    if (wall != null) {
      if (p.tool == ToolMode.demolition) p.toggleDemolition(wall.id); else p.selectWall(wall.id);
    } else {
      p.selectWall(null);
    }
  }

  void _panStart(PlanPoint world) {
    final opening = _nearestOpening(world, max: 240);
    if (opening != null) {
      draggingOpeningId = opening.id;
      p.selectOpening(opening.id);
      return;
    }
    final wall = _nearestWall(world, max: 180);
    if (wall == null) return;
    final da = (world.offset - wall.a.offset).distance;
    final db = (world.offset - wall.b.offset).distance;
    if (math.min(da, db) < 360) {
      draggingWallId = wall.id;
      dragWallStart = da <= db;
      p.selectWall(wall.id);
    }
  }

  void _panUpdate(PlanPoint world) {
    if (draggingOpeningId != null) {
      final opening = p.floor.openings.firstWhere((o) => o.id == draggingOpeningId);
      final wall = p.floor.walls.firstWhere((w) => w.id == opening.wallId);
      opening.offset = GeometryService.openingOffsetForPoint(wall, world);
      p.updateOpening(opening);
      return;
    }
    if (draggingWallId != null) {
      final wall = p.floor.walls.firstWhere((w) => w.id == draggingWallId);
      final s = GeometryService.snapPoint(world);
      if (dragWallStart) wall.a = s; else wall.b = s;
      p.updateWall(wall);
    }
  }

  void _panEnd() {
    draggingWallId = null;
    draggingOpeningId = null;
  }
}

class _Transform {
  const _Transform(this.bounds, this.size, this.scale, this.origin);
  final Rect bounds;
  final Size size;
  final double scale;
  final Offset origin;

  factory _Transform.fit(Rect bounds, Size size) {
    final sx = size.width / bounds.width;
    final sy = size.height / bounds.height;
    final scale = math.min(sx, sy).toDouble();
    final draw = Size(bounds.width * scale, bounds.height * scale);
    final origin = Offset((size.width - draw.width) / 2 - bounds.left * scale, (size.height - draw.height) / 2 - bounds.top * scale);
    return _Transform(bounds, size, scale, origin);
  }
  Offset toScreen(PlanPoint p) => Offset(origin.dx + p.x * scale, origin.dy + p.y * scale);
  PlanPoint toWorld(Offset p) => PlanPoint((p.dx - origin.dx) / scale, (p.dy - origin.dy) / scale);
}

class _PlanPainter extends CustomPainter {
  _PlanPainter({required this.project, required this.tr, required this.draftStart});
  final ZamerProject project;
  final _Transform tr;
  final PlanPoint? draftStart;

  Color phaseColor(ProjectPhase p) => switch (p) {
    ProjectPhase.existing => const Color(0xFFB9C1C4),
    ProjectPhase.demolition => const Color(0xFFFF6B56),
    ProjectPhase.newPlan => const Color(0xFF56D6A3),
  };

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = Colors.white.withOpacity(.035)..strokeWidth = 1;
    const gridMm = 500.0;
    final b = tr.bounds;
    for (var x = (b.left / gridMm).floor() * gridMm; x <= b.right; x += gridMm) {
      final a = tr.toScreen(PlanPoint(x, b.top)); final z = tr.toScreen(PlanPoint(x, b.bottom)); canvas.drawLine(a, z, grid);
    }
    for (var y = (b.top / gridMm).floor() * gridMm; y <= b.bottom; y += gridMm) {
      final a = tr.toScreen(PlanPoint(b.left, y)); final z = tr.toScreen(PlanPoint(b.right, y)); canvas.drawLine(a, z, grid);
    }

    // Draw continuous-looking walls. Round caps + matching endpoint discs remove
    // the previous "wall made of chunks" appearance at joins.
    for (final wall in project.floor.walls) {
      final selected = project.selectedWallId == wall.id;
      final paint = Paint()
        ..color = phaseColor(wall.phase)
        ..strokeWidth = math.max(4.0, wall.thickness * tr.scale).toDouble()
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      final a = tr.toScreen(wall.a); final z = tr.toScreen(wall.b);
      canvas.drawLine(a, z, paint);
      canvas.drawCircle(a, paint.strokeWidth / 2, paint);
      canvas.drawCircle(z, paint.strokeWidth / 2, paint);
      if (selected) {
        final hp = Paint()..color = Colors.amber..style = PaintingStyle.fill;
        canvas.drawCircle(a, 8, hp); canvas.drawCircle(z, 8, hp);
      }
      final mid = (a + z) / 2;
      final tp = TextPainter(text: TextSpan(text: '${wall.length.round()}', style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w700)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, mid - Offset(tp.width / 2, 22));
    }

    for (final opening in project.floor.openings) {
      final wall = project.floor.walls.firstWhere((w) => w.id == opening.wallId);
      final center = PlanPoint(wall.a.x + (wall.b.x - wall.a.x) * opening.offset, wall.a.y + (wall.b.y - wall.a.y) * opening.offset);
      final c = tr.toScreen(center);
      final angle = wall.angle;
      final half = opening.width * tr.scale / 2;
      final dx = math.cos(angle) * half; final dy = math.sin(angle) * half;
      final gap = Paint()..color = const Color(0xFF0E1517)..strokeWidth = math.max(7.0, wall.thickness * tr.scale + 4).toDouble()..strokeCap = StrokeCap.square;
      canvas.drawLine(c - Offset(dx, dy), c + Offset(dx, dy), gap);
      final op = Paint()..color = project.selectedOpeningId == opening.id ? Colors.amber : const Color(0xFF63AFFF)..strokeWidth = 3..style = PaintingStyle.stroke;
      canvas.drawLine(c - Offset(dx, dy), c + Offset(dx, dy), op);
      if (opening.type == OpeningType.door) {
        final hinge = c - Offset(dx, dy);
        final end = hinge + Offset(math.cos(angle + math.pi / 2) * opening.width * tr.scale, math.sin(angle + math.pi / 2) * opening.width * tr.scale);
        canvas.drawLine(hinge, end, op);
      } else {
        final n = Offset(-math.sin(angle), math.cos(angle)) * 5;
        canvas.drawLine(c - Offset(dx, dy) + n, c + Offset(dx, dy) + n, op);
      }
    }

    if (draftStart != null) {
      final c = tr.toScreen(draftStart!);
      canvas.drawCircle(c, 8, Paint()..color = Colors.amber);
    }
  }

  @override
  bool shouldRepaint(covariant _PlanPainter old) => true;
}

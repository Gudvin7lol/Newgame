import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ZamerApp());
}

class ZamerApp extends StatelessWidget {
  const ZamerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Замер',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF56D6A3), brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF0E1517),
        cardColor: const Color(0xFF172125),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

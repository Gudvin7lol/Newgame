import 'package:flutter/material.dart';
import '../models/project.dart';
import 'editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Замер'), actions: const [Padding(padding: EdgeInsets.only(right: 16), child: Icon(Icons.construction))]),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: const LinearGradient(colors: [Color(0xFF1B2D30), Color(0xFF152023)]),
                border: Border.all(color: Colors.white10),
              ),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('ZAMER v1.0 Professional', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
                SizedBox(height: 8),
                Text('Обмер, демонтаж и новая планировка в одной геометрической модели.', style: TextStyle(color: Colors.white70)),
              ]),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => EditorScreen(project: ZamerProject.demo()))),
              icon: const Icon(Icons.add_home_work_outlined),
              label: const Padding(padding: EdgeInsets.symmetric(vertical: 13), child: Text('Новый объект')),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.document_scanner_outlined), label: const Text('Импорт / скан плана')),
            const SizedBox(height: 28),
            const Text('Последние проекты', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.apartment)),
                title: const Text('Новый объект'),
                subtitle: const Text('1 этаж · геометрия v1'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => EditorScreen(project: ZamerProject.demo()))),
              ),
            )
          ]),
        ),
      ),
    );
  }
}

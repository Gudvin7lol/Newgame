import 'package:flutter/material.dart';
import '../models/project.dart';
import '../widgets/plan_canvas.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.project});
  final ZamerProject project;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final ZamerProject p = widget.project;
  int section = 0;

  @override
  void initState() { super.initState(); p.addListener(_changed); }
  @override
  void dispose() { p.removeListener(_changed); super.dispose(); }
  void _changed() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)), Text('${p.floor.name} · v1 Alpha 1', style: const TextStyle(fontSize: 11, color: Colors.white54))]),
        actions: [
          PopupMenuButton<int>(
            tooltip: 'Этаж',
            icon: const Icon(Icons.layers_outlined),
            itemBuilder: (_) => [
              for (var i = 0; i < p.floors.length; i++) PopupMenuItem(value: i, child: Text(p.floors[i].name)),
              const PopupMenuDivider(),
              const PopupMenuItem(value: -1, child: Row(children: [Icon(Icons.copy_all_outlined), SizedBox(width: 10), Text('Новый этаж = копия текущего')]))
            ],
            onSelected: (v) => v == -1 ? p.addFloorByCopy() : p.setFloor(v),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: Column(children: [
        _phaseLegend(),
        if (section == 0) _toolBar(),
        Expanded(child: section == 0 ? PlanCanvas(project: p, onMessage: (m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m), duration: const Duration(milliseconds: 900)))) : _modulePlaceholder()),
        _bottomNav(),
      ]),
      floatingActionButton: section == 0 && p.selectedWallId != null ? FloatingActionButton.small(
        onPressed: () => p.toggleDemolition(p.selectedWallId!),
        tooltip: 'В демонтаж / вернуть',
        child: const Icon(Icons.delete_sweep_outlined),
      ) : null,
    );
  }

  Widget _phaseLegend() => Container(
    padding: const EdgeInsets.fromLTRB(12, 7, 12, 7),
    color: const Color(0xFF121C1F),
    child: const Row(children: [
      _Dot(color: Color(0xFFB9C1C4), text: 'Существующее'), SizedBox(width: 14),
      _Dot(color: Color(0xFFFF6B56), text: 'Демонтаж'), SizedBox(width: 14),
      _Dot(color: Color(0xFF56D6A3), text: 'Новая планировка'),
    ]),
  );

  Widget _toolBar() {
    const items = <(ToolMode, IconData, String)>[
      (ToolMode.select, Icons.ads_click, 'Правка'),
      (ToolMode.wall, Icons.linear_scale, 'Стена'),
      (ToolMode.partition, Icons.view_week_outlined, 'Перегородка'),
      (ToolMode.door, Icons.door_front_door_outlined, 'Дверь'),
      (ToolMode.window, Icons.window_outlined, 'Окно'),
      (ToolMode.demolition, Icons.auto_delete_outlined, 'Демонтаж'),
    ];
    return SizedBox(height: 74, child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), scrollDirection: Axis.horizontal,
      itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(width: 7),
      itemBuilder: (_, i) { final it = items[i]; final active = p.tool == it.$1; return ChoiceChip(selected: active, onSelected: (_) => p.setTool(it.$1), avatar: Icon(it.$2, size: 18), label: Text(it.$3)); },
    ));
  }

  Widget _bottomNav() {
    const tabs = [('План', Icons.architecture), ('Развёртки', Icons.view_carousel_outlined), ('Полы', Icons.grid_4x4), ('Электрика', Icons.electrical_services), ('3D', Icons.view_in_ar), ('Инженерия', Icons.water_drop_outlined), ('Смета', Icons.receipt_long_outlined)];
    return SafeArea(top: false, child: SizedBox(height: 68, child: ListView.builder(
      scrollDirection: Axis.horizontal, itemCount: tabs.length,
      itemBuilder: (_, i) => InkWell(onTap: () => setState(() => section = i), child: Container(width: 86, padding: const EdgeInsets.symmetric(vertical: 7), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(tabs[i].$2, size: 21, color: section == i ? Theme.of(context).colorScheme.primary : Colors.white54), const SizedBox(height: 3), Text(tabs[i].$1, style: TextStyle(fontSize: 10, color: section == i ? Colors.white : Colors.white54))]))),
    )));
  }

  Widget _modulePlaceholder() {
    const titles = ['План', 'Развёртки стен', 'Раскладки пола', 'Электрика', '3D проект', 'Инженерия', 'Смета'];
    const desc = [
      '',
      'Следующий слой v1: цельные радиусные развёртки, плитка и элементы электрики.',
      'Новый движок раскладок: направление, смещение, ёлочка, подрезки и листовая подложка.',
      'Перетаскивание, рамки 2–5 постов, привязка к стенам и выравнивание светильников.',
      'Новая камера, реальные координаты объектов, скрытие ближайших стен и материалы.',
      'Потолки, вода, канализация, отопление, тёплый пол и контроль коллизий.',
      'Автоматические объёмы демонтажа, монтажа, отделки и ведомости материалов.',
    ];
    return Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.construction, size: 52, color: Colors.white24), const SizedBox(height: 18), Text(titles[section], style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), const SizedBox(height: 10), Text(desc[section], textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, height: 1.4))])));
  }
}

class _Dot extends StatelessWidget {
  const _Dot({required this.color, required this.text});
  final Color color; final String text;
  @override Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 9, height: 9, decoration: BoxDecoration(color: color, shape: BoxShape.circle)), const SizedBox(width: 5), Text(text, style: const TextStyle(fontSize: 10, color: Colors.white60))]);
}

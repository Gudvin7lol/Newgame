import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

enum ProjectPhase { existing, demolition, newPlan }
enum OpeningType { door, window }
enum ToolMode { select, wall, partition, door, window, demolition }

@immutable
class PlanPoint {
  const PlanPoint(this.x, this.y);
  final double x;
  final double y;

  Offset get offset => Offset(x, y);
  PlanPoint copyWith({double? x, double? y}) => PlanPoint(x ?? this.x, y ?? this.y);
}

class WallSegment {
  WallSegment({
    required this.id,
    required this.a,
    required this.b,
    this.thickness = 120,
    this.height = 2700,
    this.phase = ProjectPhase.existing,
    this.isPartition = false,
  });

  final String id;
  PlanPoint a;
  PlanPoint b;
  double thickness;
  double height;
  ProjectPhase phase;
  bool isPartition;

  double get length => math.sqrt(math.pow(b.x - a.x, 2) + math.pow(b.y - a.y, 2));
  double get angle => math.atan2(b.y - a.y, b.x - a.x);

  WallSegment clone() => WallSegment(
        id: id,
        a: PlanPoint(a.x, a.y),
        b: PlanPoint(b.x, b.y),
        thickness: thickness,
        height: height,
        phase: phase,
        isPartition: isPartition,
      );
}

class Opening {
  Opening({
    required this.id,
    required this.wallId,
    required this.type,
    this.offset = 0.5,
    this.width = 900,
    this.height = 2100,
    this.sillHeight = 0,
  });

  final String id;
  String wallId;
  OpeningType type;
  double offset; // 0..1 along wall centerline
  double width;
  double height;
  double sillHeight;

  Opening clone() => Opening(
        id: id,
        wallId: wallId,
        type: type,
        offset: offset,
        width: width,
        height: height,
        sillHeight: sillHeight,
      );
}

class FloorPlan {
  FloorPlan({
    required this.id,
    required this.name,
    required this.walls,
    required this.openings,
  });

  final String id;
  String name;
  final List<WallSegment> walls;
  final List<Opening> openings;

  FloorPlan cloneAs(String newId, String newName) => FloorPlan(
        id: newId,
        name: newName,
        walls: walls.map((w) => w.clone()).toList(),
        openings: openings.map((o) => o.clone()).toList(),
      );
}

class ZamerProject extends ChangeNotifier {
  ZamerProject({required this.name, required List<FloorPlan> floors}) : floors = floors;

  String name;
  final List<FloorPlan> floors;
  int activeFloorIndex = 0;
  ToolMode tool = ToolMode.select;
  String? selectedWallId;
  String? selectedOpeningId;

  FloorPlan get floor => floors[activeFloorIndex];

  void setTool(ToolMode value) {
    tool = value;
    selectedWallId = null;
    selectedOpeningId = null;
    notifyListeners();
  }

  void selectWall(String? id) {
    selectedWallId = id;
    selectedOpeningId = null;
    notifyListeners();
  }

  void selectOpening(String? id) {
    selectedOpeningId = id;
    selectedWallId = null;
    notifyListeners();
  }

  void updateWall(WallSegment wall) => notifyListeners();
  void updateOpening(Opening opening) => notifyListeners();

  void toggleDemolition(String wallId) {
    final wall = floor.walls.firstWhere((w) => w.id == wallId);
    wall.phase = wall.phase == ProjectPhase.demolition
        ? ProjectPhase.existing
        : ProjectPhase.demolition;
    notifyListeners();
  }

  void addFloorByCopy() {
    final next = floors.length + 1;
    floors.add(floor.cloneAs('floor_$next', '$next этаж'));
    activeFloorIndex = floors.length - 1;
    selectedWallId = null;
    selectedOpeningId = null;
    notifyListeners();
  }

  void setFloor(int index) {
    activeFloorIndex = index;
    selectedWallId = null;
    selectedOpeningId = null;
    notifyListeners();
  }

  static ZamerProject demo() {
    final walls = <WallSegment>[
      WallSegment(id: 'w1', a: const PlanPoint(0, 0), b: const PlanPoint(4800, 0), thickness: 180),
      WallSegment(id: 'w2', a: const PlanPoint(4800, 0), b: const PlanPoint(4800, 8000), thickness: 180),
      WallSegment(id: 'w3', a: const PlanPoint(4800, 8000), b: const PlanPoint(0, 8000), thickness: 180),
      WallSegment(id: 'w4', a: const PlanPoint(0, 8000), b: const PlanPoint(0, 0), thickness: 180),
      WallSegment(id: 'p1', a: const PlanPoint(0, 3900), b: const PlanPoint(2600, 3900), thickness: 100, isPartition: true),
      WallSegment(id: 'p2', a: const PlanPoint(3400, 3900), b: const PlanPoint(4800, 3900), thickness: 100, isPartition: true),
    ];
    final openings = <Opening>[
      Opening(id: 'd1', wallId: 'w1', type: OpeningType.door, offset: .48, width: 900),
      Opening(id: 'w01', wallId: 'w2', type: OpeningType.window, offset: .32, width: 1400, height: 1400, sillHeight: 850),
    ];
    return ZamerProject(name: 'Новый объект', floors: [FloorPlan(id: 'floor_1', name: '1 этаж', walls: walls, openings: openings)]);
  }
}

import 'package:flutter/material.dart';

class VisualMaterialPreset {
  const VisualMaterialPreset({
    required this.id,
    required this.name,
    required this.category,
    required this.color,
    this.pattern = 'solid',
  });

  final String id;
  final String name;
  final String category;
  final Color color;
  final String pattern;
}

class MaterialCatalog {
  static const presets = <VisualMaterialPreset>[
    VisualMaterialPreset(
      id: 'oak-natural',
      name: 'Дуб натуральный',
      category: 'Пол',
      color: Color(0xFFD9C3A2),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'oak-smoked',
      name: 'Дуб дымчатый',
      category: 'Пол',
      color: Color(0xFF9D8064),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'walnut',
      name: 'Орех',
      category: 'Пол',
      color: Color(0xFF84634D),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'spc-grey',
      name: 'SPC серый дуб',
      category: 'Пол',
      color: Color(0xFFB7B4AA),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'oak-light',
      name: 'Дуб белёный',
      category: 'Пол',
      color: Color(0xFFE3D8C5),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'oak-honey',
      name: 'Дуб медовый',
      category: 'Пол',
      color: Color(0xFFCFA977),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'ash-natural',
      name: 'Ясень натуральный',
      category: 'Пол',
      color: Color(0xFFD9CCB6),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'laminate-wenge',
      name: 'Венге',
      category: 'Пол',
      color: Color(0xFF594C42),
      pattern: 'wood',
    ),
    VisualMaterialPreset(
      id: 'tile-light-stone',
      name: 'Керамогранит светлый камень',
      category: 'Плитка',
      color: Color(0xFFD9DDD9),
      pattern: 'tile',
    ),
    VisualMaterialPreset(
      id: 'tile-concrete',
      name: 'Керамогранит бетон',
      category: 'Плитка',
      color: Color(0xFFBFC4C7),
      pattern: 'tile',
    ),
    VisualMaterialPreset(
      id: 'tile-marble',
      name: 'Керамогранит мрамор',
      category: 'Плитка',
      color: Color(0xFFE8E6E1),
      pattern: 'tile',
    ),
    VisualMaterialPreset(
      id: 'tile-dark',
      name: 'Керамогранит графит',
      category: 'Плитка',
      color: Color(0xFF6D7378),
      pattern: 'tile',
    ),
    VisualMaterialPreset(
      id: 'tile-travertine',
      name: 'Травертин',
      category: 'Плитка',
      color: Color(0xFFD3C5AC),
      pattern: 'tile',
    ),
    VisualMaterialPreset(
      id: 'tile-terrazzo',
      name: 'Терраццо',
      category: 'Плитка',
      color: Color(0xFFD6D3CA),
      pattern: 'concrete',
    ),
    VisualMaterialPreset(
      id: 'tile-sand',
      name: 'Керамогранит песочный',
      category: 'Плитка',
      color: Color(0xFFD9C9AF),
      pattern: 'tile',
    ),
    VisualMaterialPreset(
      id: 'tile-emerald',
      name: 'Плитка зелёная',
      category: 'Плитка',
      color: Color(0xFF55766B),
      pattern: 'tile',
    ),
    VisualMaterialPreset(
      id: 'paint-warm-white',
      name: 'Краска тёплый белый',
      category: 'Стены',
      color: Color(0xFFF2EFE8),
    ),
    VisualMaterialPreset(
      id: 'paint-cool-white',
      name: 'Краска холодный белый',
      category: 'Стены',
      color: Color(0xFFF2F5F7),
    ),
    VisualMaterialPreset(
      id: 'paint-sage',
      name: 'Краска шалфей',
      category: 'Стены',
      color: Color(0xFFC9D2C6),
    ),
    VisualMaterialPreset(
      id: 'paint-greige',
      name: 'Краска грейдж',
      category: 'Стены',
      color: Color(0xFFD4CCC0),
    ),
    VisualMaterialPreset(
      id: 'paint-olive',
      name: 'Краска оливковая',
      category: 'Стены',
      color: Color(0xFFB5BBA6),
    ),
    VisualMaterialPreset(
      id: 'paint-clay',
      name: 'Краска терракота',
      category: 'Стены',
      color: Color(0xFFD1A38F),
    ),
    VisualMaterialPreset(
      id: 'paint-blue',
      name: 'Краска пыльно-голубая',
      category: 'Стены',
      color: Color(0xFFB4C5CB),
    ),
    VisualMaterialPreset(
      id: 'plaster-sand',
      name: 'Декоративная штукатурка',
      category: 'Стены',
      color: Color(0xFFD2C7B6),
      pattern: 'concrete',
    ),
    VisualMaterialPreset(
      id: 'concrete-raw',
      name: 'Бетон',
      category: 'Стены',
      color: Color(0xFFC4C6C7),
      pattern: 'concrete',
    ),
    VisualMaterialPreset(
      id: 'brick-red',
      name: 'Кирпич',
      category: 'Стены',
      color: Color(0xFFC98672),
      pattern: 'brick',
    ),
  ];

  static VisualMaterialPreset byId(String id) =>
      presets.firstWhere((e) => e.id == id, orElse: () => presets.first);

  static List<VisualMaterialPreset> forCategory(String category) =>
      presets.where((e) => e.category == category).toList(growable: false);

  static List<VisualMaterialPreset> get floorFinishes => presets
      .where((e) => e.category == 'Пол' || e.category == 'Плитка')
      .toList(growable: false);
  static List<VisualMaterialPreset> get wallFinishes => presets
      .where((e) => e.category == 'Стены' || e.category == 'Плитка')
      .toList(growable: false);
}

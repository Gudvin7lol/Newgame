import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_scene/scene.dart';
import 'package:vector_math/vector_math.dart' as vm;

import '../models/models.dart';
import '../services/material_catalog.dart';
import '../widgets/floor_3d_painter.dart';
import 'model_asset_catalog.dart';
import 'zamer_scene_geometry.dart';

/// GPU-backed 3D viewport for Zamер.
///
/// Measurement data remains in millimetres in [FloorPlan]. It is converted to
/// metres only at the renderer boundary because Flutter Scene uses metres and
/// +Y as the up axis. This keeps CAD/measurement calculations deterministic
/// while allowing a conventional realtime 3D scene.
class ZamerGpuViewport extends StatefulWidget {
  const ZamerGpuViewport({
    super.key,
    required this.floor,
    required this.rotation,
    required this.tilt,
    required this.zoom,
    required this.cutaway,
    required this.pan,
    required this.walkMode,
    required this.walkX,
    required this.walkY,
  });

  final FloorPlan floor;
  final double rotation;
  final double tilt;
  final double zoom;
  final bool cutaway;
  final Offset pan;
  final bool walkMode;
  final double walkX;
  final double walkY;

  @override
  State<ZamerGpuViewport> createState() => ZamerGpuViewportState();
}

class ZamerGpuViewportState extends State<ZamerGpuViewport>
    with WidgetsBindingObserver {
  Scene? _scene;
  final Map<String, Node> _modelTemplates = <String, Node>{};
  final List<_WallVisual> _wallVisuals = <_WallVisual>[];
  Texture2D? _laminateTexture;
  Texture2D? _tileTexture;
  Texture2D? _concreteTexture;
  Texture2D? _plasterTexture;

  ZamerSceneGeometry? _geometry;
  Object? _loadError;
  bool _ready = false;
  int _buildGeneration = 0;
  bool _initializing = false;
  int _retryAttempt = 0;
  Timer? _retryTimer;
  int _lastFloorFingerprint = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _lastFloorFingerprint = _floorFingerprint();
    // Wait until the visible 3D tab has produced its first Android surface.
    // Initialising Flutter Scene while this widget was offstage was the main
    // reason some devices needed a complete app restart before 3D appeared.
    WidgetsBinding.instance.addPostFrameCallback((_) => _initialize());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_ready) {
      _scheduleRetry(immediate: true);
    }
  }

  void _scheduleRetry({bool immediate = false}) {
    if (!mounted || _ready) return;
    _retryTimer?.cancel();
    _retryAttempt++;
    final delay = immediate
        ? Duration.zero
        : Duration(milliseconds: math.min(3200, 350 + _retryAttempt * 350));
    _retryTimer = Timer(delay, _initialize);
  }

  @override
  void didUpdateWidget(covariant ZamerGpuViewport oldWidget) {
    super.didUpdateWidget(oldWidget);
    final fingerprint = _floorFingerprint();
    if (!identical(oldWidget.floor, widget.floor) ||
        fingerprint != _lastFloorFingerprint) {
      _lastFloorFingerprint = fingerprint;
      _rebuildScene();
    }
  }

  int _floorFingerprint() {
    final values = <Object?>[
      widget.floor.defaultHeightMm,
      widget.floor.walls.length,
      widget.floor.planObjects.length,
      widget.floor.electricalPoints.length,
    ];
    for (final wall in widget.floor.walls) {
      values.addAll(<Object?>[
        wall.id,
        wall.startNodeId,
        wall.endNodeId,
        wall.thicknessMm,
        wall.heightOverrideMm,
        wall.openings.length,
      ]);
    }
    for (final meta in widget.floor.roomMetaByKey.values) {
      final m = meta.materials;
      values.addAll(<Object?>[
        meta.faceKey,
        m.floorMode,
        m.floorMaterialId,
        m.floorDirectionDeg,
        m.tileWidthMm,
        m.tileHeightMm,
        m.laminatePlankLengthMm,
        m.laminatePlankWidthMm,
        m.wallMaterialId,
        m.wallTile,
        m.wallTileMaterialId,
      ]);
    }
    for (final object in widget.floor.planObjects) {
      values.addAll(<Object?>[
        object.id,
        object.catalogId,
        object.xMm,
        object.yMm,
        object.widthMm,
        object.depthMm,
        object.heightMm,
        object.elevationMm,
        object.rotationDeg,
      ]);
    }
    return Object.hashAll(values);
  }

  Future<void> _initialize() async {
    if (_initializing || !mounted) return;
    _initializing = true;
    try {
      // flutter_scene requires its static GPU resources to be initialized
      // after a real surface exists. The viewport now retries automatically,
      // so a transient first-frame GPU failure never requires an app restart.
      await Scene.initializeStaticResources();
      if (!mounted) return;
      _scene?.removeAll();
      _scene = Scene();
      _configureScene();
      await _loadFinishTextures();
      await _rebuildScene();
      if (!mounted) return;
      _retryTimer?.cancel();
      _retryAttempt = 0;
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loadError = error;
        _ready = false;
      });
      _scheduleRetry();
    } finally {
      _initializing = false;
    }
  }

  void retryGpu() {
    _retryAttempt = 0;
    _scheduleRetry(immediate: true);
  }

  void _configureScene() {
    final scene = _scene;
    if (scene == null) return;
    scene.environmentSettings = EnvironmentSettings(
      toneMapping: ToneMappingMode.pbrNeutral,
      environmentIntensity: 0.90,
      exposure: 1.0,
      ambientOcclusionEnabled: false,
      screenSpaceReflectionsEnabled: false,
      bloomEnabled: false,
      vignetteEnabled: false,
      autoExposureEnabled: false,
    );
    scene.antiAliasingMode = AntiAliasingMode.auto;
    scene.environmentIntensity = 0.90;
    scene.directionalLight = DirectionalLight(
      direction: vm.Vector3(-0.45, -1.0, -0.32)..normalize(),
      color: vm.Vector3(1.0, 0.97, 0.92),
      intensity: 2.45,
      castsShadow: true,
      cacheStaticShadows: false,
      shadowMapResolution: 512,
      shadowMaxDistance: 35,
      shadowSoftness: 0.12,
    );
    // The first GPU version used a fairly expensive mobile AO profile. A
    // lighter half-resolution profile is much more stable on mid-range Android
    // GPUs while keeping enough depth to read the room shape.
    scene.ambientOcclusion
      ..enabled = false
      ..halfResolution = true
      ..sampleCount = 2
      ..radius = 0.20
      ..intensity = 0.55
      ..bias = 0.04;
  }

  void _configurePhotoLighting() {
    final scene = _scene;
    if (scene == null) return;
    scene.environmentSettings = EnvironmentSettings(
      toneMapping: ToneMappingMode.pbrNeutral,
      environmentIntensity: 1.15,
      exposure: 1.06,
      colorGradingEnabled: true,
      brightness: 1.01,
      contrast: 1.04,
      saturation: 1.025,
      temperature: 0.025,
      ambientOcclusionEnabled: true,
      ambientOcclusionRadius: 0.28,
      ambientOcclusionIntensity: 0.72,
      ambientOcclusionBias: 0.035,
      ambientOcclusionSampleCount: 8,
      ambientOcclusionHalfResolution: true,
      screenSpaceReflectionsEnabled: true,
      screenSpaceReflectionsIntensity: 0.55,
      screenSpaceReflectionsMaxDistance: 18,
      screenSpaceReflectionsThickness: 0.42,
      screenSpaceReflectionsStride: 5,
      screenSpaceReflectionsMaxSteps: 72,
      screenSpaceReflectionsBlur: 0.24,
      screenSpaceReflectionsResolutionScale: 0.75,
      bloomEnabled: true,
      bloomThreshold: 1.12,
      bloomIntensity: 0.09,
      bloomScatter: 0.62,
      vignetteEnabled: true,
      vignetteIntensity: 0.08,
      vignetteRadius: 0.86,
      vignetteSmoothness: 0.55,
      autoExposureEnabled: true,
      autoExposureStrength: 0.45,
      autoExposureCompensation: 0.15,
      autoExposureMinEv: -1.2,
      autoExposureMaxEv: 1.8,
    );
    scene.antiAliasingMode = AntiAliasingMode.auto;
    scene.environmentIntensity = 1.15;
    scene.directionalLight = DirectionalLight(
      direction: vm.Vector3(-0.38, -1.0, -0.28)..normalize(),
      color: vm.Vector3(1.0, 0.965, 0.90),
      intensity: 3.05,
      castsShadow: true,
      cacheStaticShadows: false,
      shadowMapResolution: 1024,
      shadowMaxDistance: 45,
      shadowSoftness: 0.24,
    );
    scene.ambientOcclusion
      ..enabled = true
      ..halfResolution = true
      ..sampleCount = 4
      ..radius = 0.28
      ..intensity = 0.72
      ..bias = 0.035;
  }

  Future<void> _loadFinishTextures() async {
    _laminateTexture ??= await Texture2D.fromAsset(
      'assets/textures/laminate_oak.png',
    );
    _tileTexture ??= await Texture2D.fromAsset(
      'assets/textures/tile_light_stone.png',
    );
    _concreteTexture ??= await Texture2D.fromAsset(
      'assets/textures/concrete_soft.png',
    );
    _plasterTexture ??= await Texture2D.fromAsset(
      'assets/textures/plaster_warm.png',
    );
  }

  Future<void> _rebuildScene() async {
    final generation = ++_buildGeneration;
    if (mounted) {
      setState(() {
        _ready = false;
        _loadError = null;
      });
    }

    final scene = _scene;
    if (scene == null) {
      if (mounted) {
        setState(() {
          _loadError = StateError('GPU-контекст недоступен');
          _ready = false;
        });
      }
      return;
    }

    final geometry = ZamerSceneGeometry.fromFloor(widget.floor);
    _geometry = geometry;
    scene.removeAll();
    _wallVisuals.clear();

    final floorMaterialCache = <String, PhysicallyBasedMaterial>{};
    for (final surface in geometry.floors) {
      final node = _buildFloorNode(surface, geometry.bounds, floorMaterialCache);
      if (node != null) scene.add(node);
    }

    final wallMaterialCache = <String, PhysicallyBasedMaterial>{};
    for (final wall in geometry.walls) {
      final finishId = wall.tileEnabled ? wall.tileMaterialId : wall.materialId;
      final key = '${wall.tileEnabled ? 'tile' : 'wall'}:$finishId';
      final wallMaterial = wallMaterialCache.putIfAbsent(
        key,
        () => _wallMaterial(wall),
      );
      final node = _buildWallNode(wall, geometry.bounds, wallMaterial);
      scene.add(node);
      _wallVisuals.add(
        _WallVisual(
          node: node,
          x: _mx(wall.centerXMm, geometry.bounds),
          z: _mz(wall.centerYMm, geometry.bounds),
        ),
      );
    }

    for (final opening in geometry.openings) {
      scene.add(_buildOpeningNode(opening, geometry.bounds));
    }
    for (final point in geometry.electrical) {
      scene.add(_buildElectricalNode(point, geometry.bounds));
    }

    for (final object in geometry.objects) {
      if (generation != _buildGeneration) return;
      final node = await _buildObjectNode(object, geometry.bounds);
      if (generation != _buildGeneration) return;
      scene.add(node);
    }

    if (!mounted || generation != _buildGeneration) return;
    setState(() => _ready = true);
  }

  Node? _buildFloorNode(
    ZamerFloorSurface surface,
    ZamerSceneBounds bounds,
    Map<String, PhysicallyBasedMaterial> materialCache,
  ) {
    if (surface.polygonMm.length < 3) return null;
    final indices = _triangulate(surface.polygonMm);
    if (indices.isEmpty) return null;

    final uvScale = _floorUvScaleMm(surface);
    final angle = surface.directionDeg * math.pi / 180;
    final ca = math.cos(angle), sa = math.sin(angle);
    final builder = GeometryBuilder(deduplicate: false)
      ..normal(vm.Vector3(0, 1, 0));
    for (final point in surface.polygonMm) {
      final rx = point.x * ca + point.y * sa;
      final ry = -point.x * sa + point.y * ca;
      builder
        ..texCoord(vm.Vector2(rx / uvScale.$1, ry / uvScale.$2))
        ..addVertex(
          vm.Vector3(
            _mx(point.x, bounds),
            0,
            _mz(point.y, bounds),
          ),
        );
    }
    for (var i = 0; i < indices.length; i += 3) {
      builder.addTriangle(indices[i], indices[i + 1], indices[i + 2]);
    }

    final key = '${surface.materialMode}:${surface.materialId}';
    final material = materialCache.putIfAbsent(
      key,
      () => _floorMaterial(surface),
    );
    return Node(
      name: 'floor:${surface.roomKey}',
      mesh: Mesh(builder.build(), material),
    )
      ..castsShadows = false
      ..shadowStatic = true;
  }

  PhysicallyBasedMaterial _floorMaterial(ZamerFloorSurface surface) {
    final preset = MaterialCatalog.byId(surface.materialId);
    final mode = surface.materialMode.toLowerCase();
    final texture = _textureForPattern(preset.pattern, fallbackMode: mode);
    final roughness = preset.pattern == 'tile'
        ? 0.46
        : preset.pattern == 'wood'
            ? 0.62
            : preset.pattern == 'concrete'
                ? 0.88
                : 0.72;
    return _pbr(
      _vectorColor(preset.color),
      roughness: roughness,
      texture: texture,
    )..doubleSided = true;
  }

  (double, double) _floorUvScaleMm(ZamerFloorSurface surface) {
    final mode = surface.materialMode.toLowerCase();
    if (mode.contains('tile') || mode.contains('плит')) {
      return (
        math.max(60.0, surface.tileWidthMm),
        math.max(60.0, surface.tileHeightMm),
      );
    }
    if (mode.contains('concrete') || mode.contains('бетон')) {
      return const (1000.0, 1000.0);
    }
    return (
      math.max(120.0, surface.plankLengthMm),
      math.max(40.0, surface.plankWidthMm),
    );
  }

  PhysicallyBasedMaterial _wallMaterial(ZamerWallPiece wall) {
    final id = wall.tileEnabled ? wall.tileMaterialId : wall.materialId;
    final preset = MaterialCatalog.byId(id);
    final texture = _textureForPattern(
      wall.tileEnabled ? 'tile' : preset.pattern,
      fallbackMode: wall.tileEnabled ? 'tile' : 'wall',
    );
    return _pbr(
      _vectorColor(preset.color),
      roughness: wall.tileEnabled ? 0.50 : (preset.pattern == 'concrete' ? 0.90 : 0.82),
      texture: texture,
    )..doubleSided = true;
  }

  TextureSource? _textureForPattern(String pattern, {required String fallbackMode}) {
    final value = pattern.toLowerCase();
    if (value == 'wood') return _laminateTexture;
    if (value == 'tile') return _tileTexture;
    if (value == 'concrete' || fallbackMode.contains('бетон')) return _concreteTexture;
    if (value == 'brick') return _plasterTexture;
    return _plasterTexture;
  }

  vm.Vector4 _vectorColor(Color color) => vm.Vector4(
        color.red / 255.0,
        color.green / 255.0,
        color.blue / 255.0,
        color.alpha / 255.0,
      );

  Node _buildWallNode(
    ZamerWallPiece wall,
    ZamerSceneBounds bounds,
    PhysicallyBasedMaterial material,
  ) {
    final geometry = CuboidGeometry(
      vm.Vector3(
        math.max(0.002, wall.lengthMm / 1000),
        math.max(0.002, wall.heightMm / 1000),
        math.max(0.002, wall.thicknessMm / 1000),
      ),
    );
    final node = Node(
      name: 'wall:${wall.wallId}',
      mesh: Mesh(geometry, material),
    );
    node
      ..position = vm.Vector3(
        _mx(wall.centerXMm, bounds),
        (wall.bottomMm + wall.heightMm / 2) / 1000,
        _mz(wall.centerYMm, bounds),
      )
      ..rotation = vm.Quaternion.axisAngle(
        vm.Vector3(0, 1, 0),
        -wall.angleRad,
      )
      ..shadowStatic = true;
    return node;
  }

  Node _buildOpeningNode(
    ZamerOpeningPlacement opening,
    ZamerSceneBounds bounds,
  ) {
    final root = Node(name: 'opening:${opening.id}')
      ..position = vm.Vector3(
        _mx(opening.xMm, bounds),
        0,
        _mz(opening.yMm, bounds),
      )
      ..rotation = vm.Quaternion.axisAngle(
        vm.Vector3(0, 1, 0),
        -opening.rotationRad,
      );

    final frameMaterial = _pbr(
      vm.Vector4(0.56, 0.43, 0.31, 1),
      roughness: 0.58,
    );
    final whiteFrameMaterial = _pbr(
      vm.Vector4(0.93, 0.94, 0.95, 1),
      roughness: 0.48,
    );
    final frame = opening.type == OpeningType.window
        ? whiteFrameMaterial
        : frameMaterial;
    final depthM = math.max(0.055, (opening.wallThicknessMm + 14) / 1000);
    final widthM = math.max(0.20, opening.widthMm / 1000);
    final heightM = math.max(0.20, opening.heightMm / 1000);
    const frameBarM = 0.045;

    Node bar({
      required String name,
      required double x,
      required double y,
      required double width,
      required double height,
      double depth = 0,
      PhysicallyBasedMaterial? material,
    }) {
      final node = Node(
        name: name,
        mesh: Mesh(
          CuboidGeometry(
            vm.Vector3(
              math.max(0.008, width),
              math.max(0.008, height),
              depth > 0 ? depth : depthM,
            ),
          ),
          material ?? frame,
        ),
      )
        ..position = vm.Vector3(x, y, 0)
        ..shadowStatic = true;
      return node;
    }

    final bottomM = opening.sillHeightMm / 1000;
    final topM = bottomM + heightM;
    root
      ..add(
        bar(
          name: 'opening-frame-left',
          x: -widthM / 2 + frameBarM / 2,
          y: bottomM + heightM / 2,
          width: frameBarM,
          height: heightM,
        ),
      )
      ..add(
        bar(
          name: 'opening-frame-right',
          x: widthM / 2 - frameBarM / 2,
          y: bottomM + heightM / 2,
          width: frameBarM,
          height: heightM,
        ),
      )
      ..add(
        bar(
          name: 'opening-frame-top',
          x: 0,
          y: topM - frameBarM / 2,
          width: widthM,
          height: frameBarM,
        ),
      );

    if (opening.type == OpeningType.window) {
      root.add(
        bar(
          name: 'opening-frame-bottom',
          x: 0,
          y: bottomM + frameBarM / 2,
          width: widthM,
          height: frameBarM,
        ),
      );
      root.add(
        bar(
          name: 'window-mullion',
          x: 0,
          y: bottomM + heightM / 2,
          width: 0.032,
          height: math.max(0.05, heightM - frameBarM * 2),
          depth: math.max(0.035, depthM * 0.62),
        ),
      );
      final glass = _pbr(
        vm.Vector4(0.72, 0.88, 0.96, 0.28),
        roughness: 0.10,
      )..doubleSided = true;
      root.add(
        bar(
          name: 'window-glass',
          x: 0,
          y: bottomM + heightM / 2,
          width: math.max(0.08, widthM - frameBarM * 2.2),
          height: math.max(0.08, heightM - frameBarM * 2.2),
          depth: 0.008,
          material: glass,
        ),
      );
    } else {
      final leftHinge = opening.doorSwing == DoorSwing.leftIn ||
          opening.doorSwing == DoorSwing.leftOut;
      final opensIn = opening.doorSwing == DoorSwing.leftIn ||
          opening.doorSwing == DoorSwing.rightIn;
      final hingeSign = leftHinge ? -1.0 : 1.0;
      final swingSign = (opensIn ? 1.0 : -1.0) * hingeSign;
      final leafWidth = math.max(0.12, widthM - frameBarM * 1.5);
      final leafHeight = math.max(0.18, heightM - frameBarM);
      final hinge = Node(name: 'door-hinge')
        ..position = vm.Vector3(
          hingeSign * (widthM / 2 - frameBarM),
          0,
          0,
        )
        ..rotation = vm.Quaternion.axisAngle(
          vm.Vector3(0, 1, 0),
          swingSign * 32 * math.pi / 180,
        );
      final leafMaterial = _pbr(
        vm.Vector4(0.68, 0.52, 0.36, 1),
        roughness: 0.62,
      );
      hinge.add(
        Node(
          name: 'door-leaf',
          mesh: Mesh(
            CuboidGeometry(vm.Vector3(leafWidth, leafHeight, 0.038)),
            leafMaterial,
          ),
        )
          ..position = vm.Vector3(-hingeSign * leafWidth / 2, leafHeight / 2, 0)
          ..shadowStatic = true,
      );
      root.add(hinge);
    }
    _markStatic(root);
    return root;
  }

  Node _buildElectricalNode(
    ZamerElectricalPlacement point,
    ZamerSceneBounds bounds,
  ) {
    final isCeiling = point.type == ElectricalPointType.ceilingLight;
    final isPanel = point.type == ElectricalPointType.panel;
    final isJunction = point.type == ElectricalPointType.junctionBox;
    final isWallLight = point.type == ElectricalPointType.wallLight;
    final moduleCount = math.max(1, point.modules.length);

    double widthM = 0.086;
    double heightM = 0.086;
    if (point.type == ElectricalPointType.frame) {
      if (point.frameVertical) {
        heightM = 0.086 * moduleCount + 0.012 * (moduleCount - 1);
      } else {
        widthM = 0.086 * moduleCount + 0.012 * (moduleCount - 1);
      }
    } else if (isPanel) {
      widthM = 0.34;
      heightM = 0.48;
    } else if (isWallLight) {
      widthM = 0.14;
      heightM = 0.18;
    } else if (isJunction) {
      widthM = heightM = 0.10;
    }

    final accent = switch (point.type) {
      ElectricalPointType.switchPoint => vm.Vector4(0.93, 0.93, 0.91, 1),
      ElectricalPointType.socket => vm.Vector4(0.90, 0.91, 0.92, 1),
      ElectricalPointType.tvSocket => vm.Vector4(0.78, 0.83, 0.88, 1),
      ElectricalPointType.dataSocket => vm.Vector4(0.72, 0.82, 0.91, 1),
      ElectricalPointType.panel => vm.Vector4(0.72, 0.75, 0.77, 1),
      ElectricalPointType.appliance => vm.Vector4(0.91, 0.77, 0.39, 1),
      _ => vm.Vector4(0.94, 0.94, 0.93, 1),
    };
    final material = _pbr(accent, roughness: 0.46);

    if (isCeiling) {
      return Node(
        name: 'electrical:${point.id}:${point.type.name}',
        mesh: Mesh(
          CuboidGeometry(vm.Vector3(0.16, 0.025, 0.16)),
          _pbr(vm.Vector4(1.0, 0.94, 0.72, 1), roughness: 0.35),
        ),
      )
        ..position = vm.Vector3(
          _mx(point.xMm, bounds),
          point.heightMm / 1000,
          _mz(point.yMm, bounds),
        )
        ..shadowStatic = true;
    }

    final nx = -math.sin(point.rotationRad);
    final ny = math.cos(point.rotationRad);
    final offsetMm = point.wallThicknessMm / 2 + 9;
    final x = point.xMm + nx * offsetMm * point.wallSide;
    final y = point.yMm + ny * offsetMm * point.wallSide;
    final depthM = isPanel ? 0.055 : (isWallLight ? 0.075 : 0.018);
    return Node(
      name: 'electrical:${point.id}:${point.type.name}',
      mesh: Mesh(
        CuboidGeometry(vm.Vector3(widthM, heightM, depthM)),
        material,
      ),
    )
      ..position = vm.Vector3(
        _mx(x, bounds),
        math.max(heightM / 2, point.heightMm / 1000),
        _mz(y, bounds),
      )
      ..rotation = vm.Quaternion.axisAngle(
        vm.Vector3(0, 1, 0),
        -point.rotationRad,
      )
      ..shadowStatic = true;
  }

  Future<Node> _buildObjectNode(
    ZamerObjectPlacement object,
    ZamerSceneBounds bounds,
  ) async {
    final asset = ZamerModelAssetCatalog.byId(object.catalogId);
    Node node;
    var importedModel = false;
    if (asset == null) {
      node = _fallbackObject(object);
    } else {
      try {
        final template = _modelTemplates[asset.assetPath] ??=
            await Node.fromGlbAsset(asset.assetPath);
        node = template.clone(recursive: true);
        importedModel = true;
        node.name = 'object:${object.id}:${object.catalogId}';
        node.scale = vm.Vector3(
          _safeRatio(object.widthMm, asset.nativeWidthMm),
          _safeRatio(object.heightMm, asset.nativeHeightMm),
          _safeRatio(object.depthMm, asset.nativeDepthMm),
        );
      } catch (_) {
        // A single bad optional model must never take the complete room down.
        node = _fallbackObject(object);
      }
    }

    node
      ..position = vm.Vector3(
        _mx(object.xMm, bounds),
        (object.elevationMm + (importedModel ? 0 : object.heightMm / 2)) / 1000,
        _mz(object.yMm, bounds),
      )
      ..rotation = vm.Quaternion.axisAngle(
        vm.Vector3(0, 1, 0),
        -object.rotationRad,
      );
    if (object.type == PlanObjectType.lighting) {
      _attachLightEmitter(node, object, importedModel: importedModel);
    }
    _markStatic(node);
    return node;
  }

  void _attachLightEmitter(
    Node objectNode,
    ZamerObjectPlacement object, {
    required bool importedModel,
  }) {
    final id = object.catalogId.toLowerCase();
    final isWall = id.startsWith('wall-sconce');
    final isFloor = id.startsWith('floor-lamp');
    final isTrack = id.startsWith('track-');
    final isPendant = id.startsWith('pendant-') || id.startsWith('chandelier-');

    // The model node is positioned at its mounting elevation. Put the light
    // emitter where a real bulb/diffuser would approximately sit, rather than
    // at the model origin. This keeps the catalogue models useful as actual
    // scene lights without requiring per-GLB light metadata.
    final localY = importedModel
        ? (isFloor
            ? math.max(0.15, object.heightMm / 1000 * 0.82)
            : isWall
                ? math.max(0.05, object.heightMm / 1000 * 0.45)
                : math.max(0.03, object.heightMm / 1000 * 0.18))
        : 0.0;

    final lightNode = Node(name: 'light:${object.id}')
      ..position = vm.Vector3(0, localY, 0);
    final intensity = isWall
        ? 2.4
        : isFloor
            ? 3.2
            : isTrack
                ? 4.8
                : isPendant
                    ? 5.8
                    : 4.0;
    final range = isWall
        ? 4.0
        : isFloor
            ? 5.0
            : 7.5;
    lightNode.addComponent(
      PointLightComponent(
        PointLight(
          color: vm.Vector3(1.0, 0.82, 0.62),
          intensity: intensity,
          range: range,
          falloffExponent: 2.0,
        ),
      ),
    );
    objectNode.add(lightNode);
  }

  Node _fallbackObject(ZamerObjectPlacement object) {
    final material = _pbr(
      vm.Vector4(0.31, 0.38, 0.45, 1),
      roughness: 0.72,
    );
    final node = Node(
      name: 'fallback:${object.id}',
      mesh: Mesh(
        CuboidGeometry(
          vm.Vector3(
            math.max(0.05, object.widthMm / 1000),
            math.max(0.05, object.heightMm / 1000),
            math.max(0.05, object.depthMm / 1000),
          ),
        ),
        material,
      ),
    );
    return node;
  }

  static void _markStatic(Node root) {
    for (final node in <Node>[root, ...root.children.expand(_walkNodes)]) {
      if (node.mesh != null) node.shadowStatic = true;
    }
  }

  static Iterable<Node> _walkNodes(Node node) sync* {
    yield node;
    for (final child in node.children) {
      yield* _walkNodes(child);
    }
  }

  static double _safeRatio(double wanted, double nativeSize) {
    if (nativeSize.abs() < 0.01) return 1;
    return wanted / nativeSize;
  }

  PhysicallyBasedMaterial _pbr(
    vm.Vector4 color, {
    required double roughness,
    TextureSource? texture,
  }) {
    final material = PhysicallyBasedMaterial(baseColorTexture: texture)
      ..baseColorFactor = color
      ..metallicFactor = 0
      ..roughnessFactor = roughness
      ..doubleSided = false;
    return material;
  }

  double _mx(double xMm, ZamerSceneBounds b) => (xMm - b.centerX) / 1000;
  double _mz(double yMm, ZamerSceneBounds b) => (yMm - b.centerY) / 1000;

  PerspectiveCamera _camera() {
    final g = _geometry;
    if (g == null) return PerspectiveCamera();
    final bounds = g.bounds;

    if (widget.walkMode) {
      final eye = vm.Vector3(
        _mx(widget.walkX, bounds),
        1.65,
        _mz(widget.walkY, bounds),
      );
      final pitch = widget.tilt.clamp(-0.7, 0.7).toDouble();
      final cp = math.cos(pitch);
      final forward = vm.Vector3(
        math.cos(widget.rotation) * cp,
        math.sin(pitch),
        math.sin(widget.rotation) * cp,
      );
      return PerspectiveCamera(
        fovRadiansY: 64 * math.pi / 180,
        position: eye,
        target: eye + forward * 4,
        up: vm.Vector3(0, 1, 0),
        fovNear: 0.035,
        fovFar: 160,
      );
    }

    final maxDimension = math.max(bounds.widthMm, bounds.depthMm) / 1000;
    final zoom = widget.zoom.clamp(0.15, 10.0).toDouble();
    final distance = math.max(1.1, math.max(3.0, maxDimension * 1.52) / zoom);
    final elevation = widget.tilt.clamp(0.12, 1.49).toDouble();
    final horizontal = math.cos(elevation) * distance;

    // Pan is stored in logical pixels in the editor. Convert it to a stable
    // world displacement proportional to the current view distance.
    final panScale = distance / 900;
    final target = vm.Vector3(
      -widget.pan.dx * panScale,
      math.max(0.35, math.min(1.25, maxDimension * 0.08)),
      -widget.pan.dy * panScale,
    );
    final eye = target +
        vm.Vector3(
          math.cos(widget.rotation) * horizontal,
          math.sin(elevation) * distance,
          math.sin(widget.rotation) * horizontal,
        );

    return PerspectiveCamera(
      fovRadiansY: 46 * math.pi / 180,
      position: eye,
      target: target,
      up: vm.Vector3(0, 1, 0),
      fovNear: 0.045,
      fovFar: math.max(120, distance * 16),
    );
  }

  void _applyCutaway(PerspectiveCamera camera) {
    if (!_ready) return;
    if (!widget.cutaway || widget.walkMode) {
      for (final wall in _wallVisuals) {
        wall.node.visible = true;
      }
      return;
    }

    final camera2 = vm.Vector2(camera.position.x, camera.position.z);
    if (camera2.length2 < 0.0001) return;
    final cameraDir = camera2.normalized();
    for (final wall in _wallVisuals) {
      final wallPos = vm.Vector2(wall.x, wall.z);
      final radial = wallPos.length;
      if (radial < 0.08) {
        wall.node.visible = true;
        continue;
      }
      // Hide only the near-facing shell. Unlike the old wall-index heuristic,
      // this remains stable for rotated, concave and multi-room plans.
      final towardCamera = wallPos.normalized().dot(cameraDir);
      wall.node.visible = towardCamera < 0.30;
    }
  }

  /// Creates an actual GPU scene render at the requested pixel dimensions.
  /// The Canvas below is only Flutter's final compositor. Geometry, lighting,
  /// shadows and PBR are rendered by Flutter Scene / Flutter GPU at [width] x
  /// [height], so this is not an upscaled screenshot of the on-screen preview.
  Future<Uint8List> renderPng({
    required int width,
    required int height,
    bool photoQuality = false,
  }) async {
    if (width <= 0 || height <= 0) throw ArgumentError('Некорректный размер');

    final scene = _scene;
    if (scene == null || !_ready) {
      return _renderFallbackPng(width: width, height: height);
    }

    final camera = _camera();
    _applyCutaway(camera);
    if (photoQuality) _configurePhotoLighting();
    try {
      final recorder = ui.PictureRecorder();
      final canvas = ui.Canvas(recorder);
      scene.render(
        camera,
        canvas,
        viewport: ui.Rect.fromLTWH(0, 0, width.toDouble(), height.toDouble()),
        pixelRatio: 1,
      );
      final picture = recorder.endRecording();
      final image = await picture.toImage(width, height);
      try {
        final data = await image.toByteData(format: ui.ImageByteFormat.png);
        if (data == null) throw StateError('GPU-кадр не удалось преобразовать в PNG');
        return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
      } finally {
        image.dispose();
      }
    } finally {
      if (photoQuality) _configureScene();
    }
  }

  Future<Uint8List> _renderFallbackPng({
    required int width,
    required int height,
  }) async {
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    final size = ui.Size(width.toDouble(), height.toDouble());
    Floor3DPainter(
      floor: widget.floor,
      rotation: widget.rotation,
      tilt: widget.tilt,
      zoom: widget.zoom,
      cutaway: widget.cutaway,
      pan: widget.pan,
      walkMode: widget.walkMode,
      walkX: widget.walkX,
      walkY: widget.walkY,
    ).paint(canvas, size);
    final picture = recorder.endRecording();
    final image = await picture.toImage(width, height);
    try {
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) {
        throw StateError('Совместимый 3D-кадр не удалось сохранить');
      }
      return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    } finally {
      image.dispose();
    }
  }

  Widget _fallbackViewport(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        CustomPaint(
          painter: Floor3DPainter(
            floor: widget.floor,
            rotation: widget.rotation,
            tilt: widget.tilt,
            zoom: widget.zoom,
            cutaway: widget.cutaway,
            pan: widget.pan,
            walkMode: widget.walkMode,
            walkX: widget.walkX,
            walkY: widget.walkY,
          ),
        ),
        Positioned(
          left: 12,
          top: 12,
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.92),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 4, 4, 4),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Совместимый 3D',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(width: 4),
                  TextButton.icon(
                    onPressed: _initializing ? null : retryGpu,
                    icon: const Icon(Icons.refresh, size: 17),
                    label: const Text('GPU'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _retryTimer?.cancel();
    _buildGeneration++;
    _scene?.removeAll();
    _modelTemplates.clear();
    _wallVisuals.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loadError != null) return _fallbackViewport(context);
    if (!_ready) {
      return const ColoredBox(
        color: Color(0xFFF3F5F7),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Собираем GPU-сцену…'),
            ],
          ),
        ),
      );
    }

    final scene = _scene;
    if (scene == null) return _fallbackViewport(context);
    final camera = _camera();
    _applyCutaway(camera);
    return SceneView(
      scene,
      camera: camera,
      warmUp: true,
    );
  }
}

class _WallVisual {
  const _WallVisual({required this.node, required this.x, required this.z});
  final Node node;
  final double x;
  final double z;
}

/// Ear-clipping triangulation for simple room polygons, including concave ones.
/// The returned triangle winding is normalized and floor materials are double
/// sided only when needed, so concave rooms do not disappear at oblique views.
List<int> _triangulate(List<math.Point<double>> polygon) {
  if (polygon.length < 3) return const <int>[];
  final vertices = List<int>.generate(polygon.length, (i) => i);
  final result = <int>[];
  final ccw = _signedArea(polygon) > 0;
  var guard = polygon.length * polygon.length;

  while (vertices.length > 3 && guard-- > 0) {
    var clipped = false;
    for (var i = 0; i < vertices.length; i++) {
      final prev = vertices[(i - 1 + vertices.length) % vertices.length];
      final cur = vertices[i];
      final next = vertices[(i + 1) % vertices.length];
      final a = polygon[prev];
      final b = polygon[cur];
      final c = polygon[next];
      final cross = _cross(a, b, c);
      if (ccw ? cross <= 0.000001 : cross >= -0.000001) continue;

      var contains = false;
      for (final candidate in vertices) {
        if (candidate == prev || candidate == cur || candidate == next) continue;
        if (_pointInTriangle(polygon[candidate], a, b, c)) {
          contains = true;
          break;
        }
      }
      if (contains) continue;

      if (ccw) {
        result.addAll(<int>[prev, cur, next]);
      } else {
        result.addAll(<int>[next, cur, prev]);
      }
      vertices.removeAt(i);
      clipped = true;
      break;
    }
    if (!clipped) break;
  }

  if (vertices.length == 3) {
    if (ccw) {
      result.addAll(vertices);
    } else {
      result.addAll(<int>[vertices[2], vertices[1], vertices[0]]);
    }
  }
  return result;
}

double _signedArea(List<math.Point<double>> p) {
  var area = 0.0;
  for (var i = 0; i < p.length; i++) {
    final a = p[i];
    final b = p[(i + 1) % p.length];
    area += a.x * b.y - b.x * a.y;
  }
  return area / 2;
}

double _cross(
  math.Point<double> a,
  math.Point<double> b,
  math.Point<double> c,
) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);

bool _pointInTriangle(
  math.Point<double> p,
  math.Point<double> a,
  math.Point<double> b,
  math.Point<double> c,
) {
  final c1 = _cross(a, b, p);
  final c2 = _cross(b, c, p);
  final c3 = _cross(c, a, p);
  final hasNeg = c1 < -0.000001 || c2 < -0.000001 || c3 < -0.000001;
  final hasPos = c1 > 0.000001 || c2 > 0.000001 || c3 > 0.000001;
  return !(hasNeg && hasPos);
}

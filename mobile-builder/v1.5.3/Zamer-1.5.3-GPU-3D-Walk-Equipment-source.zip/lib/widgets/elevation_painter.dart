import 'dart:math' as math;
import 'package:flutter/material.dart';

import '../models/models.dart';
import '../services/geometry_service.dart';

class ElevationPainter extends CustomPainter {
  ElevationPainter({
    required this.floor,
    required this.face,
    required this.run,
    required this.heightMm,
    required this.settings,
  });

  final FloorPlan floor;
  final RoomFace face;
  final ElevationRun run;
  final double heightMm;
  final RoomMaterialSettings settings;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    final runLen = run.lengthMm;
    if (runLen <= 0) return;

    // On a narrow phone the inline canvas used to be barely taller than
    // twice the old 52 px margin, shrinking a 2.7 m wall to a tiny square.
    final horizontalMargin = math.min(38.0, size.width * .09);
    final verticalMargin = math.min(34.0, size.height * .12);
    final scale = math.min(
      (size.width - horizontalMargin * 2) / runLen,
      (size.height - verticalMargin * 2) / heightMm,
    );
    final drawW = runLen * scale;
    final drawH = heightMm * scale;
    final left = (size.width - drawW) / 2;
    final top = (size.height - drawH) / 2;
    final rect = Rect.fromLTWH(left, top, drawW, drawH);

    canvas.drawRect(rect, Paint()..color = const Color(0xFFF5F6F8));
    if (settings.wallTileEnabledFor(run.id))
      _drawWallTiles(canvas, rect, scale);
    canvas.drawRect(
      rect,
      Paint()
        ..color = const Color(0xFF20242A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );

    var accumulated = 0.0;
    for (final edge in run.edges) {
      final wall = floor.wallById(edge.wallId);
      if (wall == null) continue;
      final segmentLen = GeometryService.wallFaceLengthMm(face, edge);
      for (final opening in wall.openings) {
        final faceOffset = GeometryService.openingOffsetFromFaceStart(
          floor,
          face,
          edge,
          opening,
        );
        final totalOffset = accumulated + faceOffset;
        final x = left + totalOffset * scale;
        final w = opening.widthMm * scale;
        final yBottom = rect.bottom - opening.sillHeightMm * scale;
        final h = opening.heightMm * scale;
        final oRect = Rect.fromLTWH(x, yBottom - h, w, h);
        canvas.drawRect(
          oRect,
          Paint()
            ..color = opening.type == OpeningType.window
                ? const Color(0xFFD8E9FF)
                : const Color(0xFFFFE7D2),
        );
        canvas.drawRect(
          oRect,
          Paint()
            ..color = const Color(0xFF59616D)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5,
        );
        _label(
          canvas,
          opening.type == OpeningType.window
              ? 'Окно\n${opening.widthMm.round()}×${opening.heightMm.round()}'
              : 'Дверь\n${opening.widthMm.round()}×${opening.heightMm.round()}',
          oRect.center,
          11,
        );
        _dimensionText(
          canvas,
          '${totalOffset.round()}',
          Offset(x, rect.bottom + 20),
        );
      }
      _drawElectricalForEdge(
        canvas,
        rect,
        scale,
        accumulated,
        edge,
        wall,
        segmentLen,
      );
      accumulated += segmentLen;
    }

    _dimensionLine(
      canvas,
      Offset(left, top - 22),
      Offset(rect.right, top - 22),
      '${runLen.round()} мм${run.isCurved ? ' по дуге' : ''}',
    );
    _dimensionLine(
      canvas,
      Offset(left - 28, top),
      Offset(left - 28, rect.bottom),
      '${heightMm.round()} мм',
      vertical: true,
    );
  }

  void _drawWallTiles(Canvas canvas, Rect rect, double scale) {
    final from = settings.wallTileFromMm.clamp(0, heightMm).toDouble();
    final to = settings.wallTileToMm.clamp(from, heightMm).toDouble();
    if (to <= from) return;
    final topY = rect.bottom - to * scale;
    final bottomY = rect.bottom - from * scale;
    final tileRect = Rect.fromLTRB(rect.left, topY, rect.right, bottomY);
    canvas.save();
    canvas.clipRect(tileRect);
    canvas.drawRect(tileRect, Paint()..color = const Color(0xFFF1F3F5));
    final tw = math.max(1.0, settings.wallTileWidthMm * scale);
    final th = math.max(1.0, settings.wallTileHeightMm * scale);
    final offX =
        (settings.wallTileXFor(run.id) % settings.wallTileWidthMm) * scale;
    final offY =
        (settings.wallTileYFor(run.id) % settings.wallTileHeightMm) * scale;
    final stroke = Paint()
      ..color = const Color(0xFFB0B7C0)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    var row = 0;
    for (
      double y = tileRect.top - th + offY;
      y < tileRect.bottom + th;
      y += th
    ) {
      final rowOffset = settings.wallTilePattern == 'half' && row.isOdd
          ? tw / 2
          : 0.0;
      for (
        double x = tileRect.left - tw + offX + rowOffset;
        x < tileRect.right + tw;
        x += tw
      ) {
        canvas.drawRect(Rect.fromLTWH(x, y, tw, th), stroke);
      }
      row++;
    }
    canvas.restore();
    canvas.drawRect(
      tileRect,
      Paint()
        ..color = const Color(0xFF8D98A5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
  }

  void _drawElectricalForEdge(
    Canvas canvas,
    Rect rect,
    double scale,
    double accumulated,
    FaceEdge edge,
    PlanWall wall,
    double segmentLen,
  ) {
    for (final point in floor.electricalPoints) {
      if (point.wallId != wall.id || !point.isWallDevice) continue;
      final insideSide = edge.fromNodeId == wall.startNodeId ? 1 : -1;
      if (point.wallSide != insideSide) continue;
      var offset = point.wallOffsetMm ?? 0;
      if (edge.fromNodeId != wall.startNodeId) {
        offset = floor.wallLengthMm(wall) - offset;
      }
      offset -= GeometryService.wallFaceStartShiftMm(floor, face, edge);
      final x = rect.left + (accumulated + offset) * scale;
      final y =
          rect.bottom - point.heightMm.clamp(0, heightMm).toDouble() * scale;
      _electricalSymbol(canvas, Offset(x, y), point);
      _dimensionText(canvas, '${point.heightMm.round()}', Offset(x + 18, y));
    }
  }

  void _electricalSymbol(Canvas canvas, Offset c, ElectricalPoint p) {
    final stroke = Paint()
      ..color = const Color(0xFFB24D2B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final fill = Paint()..color = const Color(0xFFFFFFFF);
    if (p.type == ElectricalPointType.wallLight) {
      canvas.drawCircle(c, 7, fill);
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: 6),
        -math.pi / 2,
        math.pi,
        false,
        stroke,
      );
      return;
    }
    final count = math.max(1, p.modules.length);
    final w = math.max(18.0, count * 15.0);
    final r = Rect.fromCenter(center: c, width: w, height: 16);
    canvas.drawRRect(
      RRect.fromRectAndRadius(r, const Radius.circular(3)),
      fill,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(r, const Radius.circular(3)),
      stroke,
    );
    final moduleW = w / count;
    for (var i = 1; i < count; i++) {
      final x = r.left + moduleW * i;
      canvas.drawLine(Offset(x, r.top), Offset(x, r.bottom), stroke);
    }
    for (var i = 0; i < count; i++) {
      final module = i < p.modules.length
          ? p.modules[i]
          : ElectricalModuleType.socket220;
      final text = switch (module) {
        ElectricalModuleType.socket220 => '○',
        ElectricalModuleType.switch1 => 'S',
        ElectricalModuleType.switch2 => 'S2',
        ElectricalModuleType.tv => 'TV',
        ElectricalModuleType.data => 'RJ',
        ElectricalModuleType.blank => '·',
      };
      final center = Offset(r.left + moduleW * (i + 0.5), c.dy);
      _label(canvas, text, center, text.length > 1 ? 7 : 10);
    }
  }

  void _dimensionLine(
    Canvas canvas,
    Offset a,
    Offset b,
    String text, {
    bool vertical = false,
  }) {
    final p = Paint()
      ..color = const Color(0xFF6D7580)
      ..strokeWidth = 1;
    canvas.drawLine(a, b, p);
    if (vertical) {
      canvas.drawLine(a + const Offset(-5, 0), a + const Offset(5, 0), p);
      canvas.drawLine(b + const Offset(-5, 0), b + const Offset(5, 0), p);
      _dimensionText(
        canvas,
        text,
        (a + b) / 2 + const Offset(-18, 0),
        rotate: true,
      );
    } else {
      canvas.drawLine(a + const Offset(0, -5), a + const Offset(0, 5), p);
      canvas.drawLine(b + const Offset(0, -5), b + const Offset(0, 5), p);
      _dimensionText(canvas, text, (a + b) / 2 + const Offset(0, -10));
    }
  }

  void _dimensionText(
    Canvas canvas,
    String text,
    Offset center, {
    bool rotate = false,
  }) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: const TextStyle(
          color: Color(0xFF3A414A),
          fontSize: 10,
          fontWeight: FontWeight.w600,
          backgroundColor: Colors.white,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    canvas.save();
    canvas.translate(center.dx, center.dy);
    if (rotate) canvas.rotate(-math.pi / 2);
    tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
    canvas.restore();
  }

  void _label(Canvas canvas, String text, Offset center, double fontSize) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: const Color(0xFF2A3038),
          fontSize: fontSize,
          fontWeight: FontWeight.w700,
          height: 1.25,
        ),
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 130);
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant ElevationPainter oldDelegate) => true;
}

import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/models.dart';
import '../renderer3d/zamer_gpu_viewport.dart';
import '../services/walk_navigation_service.dart';

class Floor3DScreen extends StatefulWidget {
  const Floor3DScreen({super.key, required this.floor});
  final FloorPlan floor;

  @override
  State<Floor3DScreen> createState() => _Floor3DScreenState();
}

class _Floor3DScreenState extends State<Floor3DScreen> {
  double _rotation = -0.65;
  double _tilt = 0.82;
  double _zoom = 0.92;
  bool _cutaway = true;
  bool _walkMode = false;
  double _walkX = 0, _walkY = 0;
  double _overviewRotation = -0.65, _overviewTilt = 0.82;
  double _overviewZoom = 0.92;
  Offset _overviewPan = Offset.zero;
  Offset _pan = Offset.zero;
  double _gestureZoom = 1;
  Offset _gesturePan = Offset.zero;
  Offset _gestureFocal = Offset.zero;
  int _gesturePointers = 0;
  bool _rendering = false;
  final GlobalKey<ZamerGpuViewportState> _gpuKey =
      GlobalKey<ZamerGpuViewportState>();

  void _reset() => setState(() {
    if (_walkMode) _centerWalk();
    _rotation = _walkMode
        ? WalkNavigationService.startingRotation(
            widget.floor,
            math.Point(_walkX, _walkY),
          )
        : -0.65;
    _tilt = _walkMode ? 0 : 0.82;
    _zoom = _walkMode ? 1 : 0.92;
    _pan = Offset.zero;
  });

  void _topView() => setState(() {
    _walkMode = false;
    _rotation = 0;
    _tilt = 1.42;
    _zoom = 0.9;
    _pan = Offset.zero;
  });

  void _centerWalk() {
    final start = WalkNavigationService.startingPoint(widget.floor);
    _walkX = start.x;
    _walkY = start.y;
  }

  void _toggleWalk() => setState(() {
    if (!_walkMode) {
      _overviewRotation = _rotation;
      _overviewTilt = _tilt;
      _overviewZoom = _zoom;
      _overviewPan = _pan;
      _centerWalk();
      _rotation = WalkNavigationService.startingRotation(
        widget.floor,
        math.Point(_walkX, _walkY),
      );
      _tilt = 0;
      _zoom = 1;
      _pan = Offset.zero;
    } else {
      _rotation = _overviewRotation;
      _tilt = _overviewTilt;
      _zoom = _overviewZoom;
      _pan = _overviewPan;
    }
    _walkMode = !_walkMode;
  });

  void _walk(double forward, double sideways) {
    final next = WalkNavigationService.advance(
      widget.floor,
      math.Point(_walkX, _walkY),
      _rotation,
      forward,
      sideways,
    );
    if (next.x != _walkX || next.y != _walkY) {
      setState(() {
        _walkX = next.x;
        _walkY = next.y;
      });
    }
  }

  void _onScaleStart(ScaleStartDetails d) {
    _gestureZoom = _zoom;
    _gesturePan = _pan;
    _gestureFocal = d.focalPoint;
    _gesturePointers = d.pointerCount;
  }

  void _onScaleUpdate(ScaleUpdateDetails d) {
    if (d.pointerCount != _gesturePointers) {
      _gesturePointers = d.pointerCount;
      _gestureZoom = _zoom / math.max(.001, d.scale);
      _gesturePan = _pan;
      _gestureFocal = d.focalPoint;
      return;
    }
    setState(() {
      if (d.pointerCount >= 2) {
        _zoom = (_gestureZoom * d.scale)
            .clamp(_walkMode ? 0.7 : 0.15, _walkMode ? 1.4 : 10.0)
            .toDouble();
        if (!_walkMode) {
          _pan = _gesturePan + (d.focalPoint - _gestureFocal);
        }
      } else {
        final angle = _rotation + d.focalPointDelta.dx * 0.010;
        _rotation = math.atan2(math.sin(angle), math.cos(angle));
        _tilt = (_tilt - d.focalPointDelta.dy * 0.006)
            .clamp(_walkMode ? -0.7 : 0.22, _walkMode ? 0.7 : 1.48)
            .toDouble();
      }
    });
  }

  Future<void> _export4k() async {
    if (_rendering) return;
    final renderer = _gpuKey.currentState;
    if (renderer == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('GPU-сцена ещё не готова.')),
      );
      return;
    }
    setState(() => _rendering = true);
    try {
      final png = await renderer.renderPng(width: 3840, height: 2160);
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/zamer-render-${DateTime.now().millisecondsSinceEpoch}-4k.png',
      );
      await file.writeAsBytes(png, flush: true);
      await Share.shareXFiles([XFile(file.path)], text: '4K-рендер «Замер»');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Не удалось создать 4K: $e')));
      }
    } finally {
      if (mounted) setState(() => _rendering = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.floor.walls.isEmpty)
      return const Center(child: Text('Построй стены, чтобы увидеть 3D.'));
    return Column(
      children: [
        Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onScaleStart: _onScaleStart,
            onScaleUpdate: _onScaleUpdate,
            child: ClipRect(
              child: ZamerGpuViewport(
                key: _gpuKey,
                floor: widget.floor,
                rotation: _rotation,
                tilt: _tilt,
                zoom: _zoom,
                cutaway: !_walkMode && _cutaway,
                pan: _pan,
                walkMode: _walkMode,
                walkX: _walkX,
                walkY: _walkY,
              ),
            ),
          ),
        ),
        if (_walkMode)
          Card(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      TextButton.icon(
                        onPressed: _toggleWalk,
                        icon: const Icon(Icons.home_outlined),
                        label: const Text('Общий вид'),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: _reset,
                        tooltip: 'В центр комнаты',
                        icon: const Icon(Icons.my_location),
                      ),
                      IconButton(
                        onPressed: _rendering ? null : _export4k,
                        tooltip: 'Сохранить 4K PNG',
                        icon: const Icon(Icons.high_quality_outlined),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton.filledTonal(
                        tooltip: 'Шаг влево',
                        onPressed: () => _walk(0, -180),
                        icon: const Icon(Icons.chevron_left),
                      ),
                      const SizedBox(width: 12),
                      IconButton.filledTonal(
                        tooltip: 'Шаг назад',
                        onPressed: () => _walk(-180, 0),
                        icon: const Icon(Icons.keyboard_arrow_down),
                      ),
                      const SizedBox(width: 12),
                      IconButton.filled(
                        tooltip: 'Шаг вперёд',
                        onPressed: () => _walk(180, 0),
                        icon: const Icon(Icons.keyboard_arrow_up),
                      ),
                      const SizedBox(width: 12),
                      IconButton.filledTonal(
                        tooltip: 'Шаг вправо',
                        onPressed: () => _walk(0, 180),
                        icon: const Icon(Icons.chevron_right),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          )
        else
          Card(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Icon(Icons.rotate_right),
                      Expanded(
                        child: Slider(
                          value: _rotation,
                          min: -math.pi,
                          max: math.pi,
                          onChanged: (v) => setState(() => _rotation = v),
                        ),
                      ),
                      IconButton(
                        onPressed: _reset,
                        tooltip: '3/4 сверху',
                        icon: const Icon(Icons.restart_alt),
                      ),
                      IconButton(
                        onPressed: _topView,
                        tooltip: 'Вид сверху',
                        icon: const Icon(Icons.vertical_align_top),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Icon(Icons.zoom_out_map),
                      Expanded(
                        child: Slider(
                          value: _zoom,
                          min: 0.15,
                          max: 10.0,
                          onChanged: (v) => setState(() => _zoom = v),
                        ),
                      ),
                    ],
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        TextButton.icon(
                          onPressed: _toggleWalk,
                          icon: const Icon(Icons.directions_walk),
                          label: const Text('Прогулка'),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: SwitchListTile.adaptive(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          value: _cutaway,
                          onChanged: (v) => setState(() => _cutaway = v),
                          title: const Text('Открытая комната'),
                          subtitle: const Text(
                            'Скрываются наружные стены со стороны камеры.',
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      FilledButton.tonalIcon(
                        onPressed: _rendering ? null : _export4k,
                        icon: _rendering
                            ? const SizedBox.square(
                                dimension: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            : const Icon(Icons.high_quality_outlined),
                        label: const Text('4K PNG'),
                      ),
                    ],
                  ),
                  Text(
                    '1 палец — вращение/наклон. 2 пальца — перемещение и масштаб.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Color(0xFF68717D)),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}
